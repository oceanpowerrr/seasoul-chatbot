# SEASOUL Chatbot

This is a simple starter template.